import { AppPage } from './app.po';

describe('new App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should be blank', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toContain(
      'Concordo que os desenvolvedores não são responsáveis pelos meus ganhos'
      + ' e perdas'
    );
  });
});
