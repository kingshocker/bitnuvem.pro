export enum ConcordaIsencaoResponsabilidade {
  PERDAS_GANHOS = 'concorda-isencao-responsabilidade-perdas-ganhos',
  CORRETORAS = 'concorda-isencao-responsabilidade-corretoras',
}
